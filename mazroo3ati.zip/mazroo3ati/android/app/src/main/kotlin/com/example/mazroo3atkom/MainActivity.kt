package com.example.mazroo3atkom

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
